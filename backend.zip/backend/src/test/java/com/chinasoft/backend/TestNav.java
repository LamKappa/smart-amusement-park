package com.chinasoft.backend;

import cn.hutool.http.HttpUtil;
import org.junit.Test;

import java.util.HashMap;

public class TestNav {
    @Test
    public void testNav(){
//        HashMap<String, Object> paramMap = new HashMap<>();
//        paramMap.put("origin", userLongitude + "," + userLatitude);
//        paramMap.put("destination", facilityLongitude + "," + facilityLatitude);
//        paramMap.put("key", "a78b0915a81134b501c379379e908f12");
//
//        String result= HttpUtil.get("https://restapi.amap.com/v3/direction/walking", paramMap);
//
//        // 处理高德api数据
//        System.out.println(paramMap);
//        System.out.println(result);
    }
}
