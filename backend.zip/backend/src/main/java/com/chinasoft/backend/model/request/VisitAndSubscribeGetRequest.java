package com.chinasoft.backend.model.request;

import lombok.Data;

@Data
public class VisitAndSubscribeGetRequest {

    private Long userId;

}
