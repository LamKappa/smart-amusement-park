package com.chinasoft.backend.constant;

public interface FacilityTypeConstant {
    Integer AMUSEMENT_TYPE = 0;

    Integer RESTAURANT_TYPE = 1;

    Integer BASE_TYPE = 2;
}
