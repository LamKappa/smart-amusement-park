package com.chinasoft.backend.model.request.user;

public class UserPositon {
}
