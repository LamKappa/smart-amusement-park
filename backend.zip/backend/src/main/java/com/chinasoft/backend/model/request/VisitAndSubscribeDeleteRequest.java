package com.chinasoft.backend.model.request;

import lombok.Data;

@Data
public class VisitAndSubscribeDeleteRequest {

    private Long id;

}
