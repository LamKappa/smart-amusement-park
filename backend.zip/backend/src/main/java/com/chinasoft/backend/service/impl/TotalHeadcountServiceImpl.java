package com.chinasoft.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.chinasoft.backend.model.entity.TotalHeadcount;
import com.chinasoft.backend.service.TotalHeadcountService;
import com.chinasoft.backend.mapper.TotalHeadcountMapper;
import org.springframework.stereotype.Service;

/**
* @author 皎皎
* @description 针对表【total_headcount(总人数统计表)】的数据库操作Service实现
* @createDate 2024-04-10 17:56:36
*/
@Service
public class TotalHeadcountServiceImpl extends ServiceImpl<TotalHeadcountMapper, TotalHeadcount>
    implements TotalHeadcountService{

    @Override
    public Integer getTotalCount() {
        return null;
    }
}




